-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-01-2025 a las 14:36:30
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `balonpie`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipos`
--

CREATE TABLE `equipos` (
  `idEquipo` int(11) NOT NULL,
  `nombreEquipo` varchar(50) NOT NULL,
  `idEstadio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `equipos`
--

INSERT INTO `equipos` (`idEquipo`, `nombreEquipo`, `idEstadio`) VALUES
(1, 'Club América', 1),
(2, 'FC Barcelona', 2),
(3, 'Real Madrid', 3),
(4, 'Rayo Vallecano', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estadios`
--

CREATE TABLE `estadios` (
  `idEstadio` int(11) NOT NULL,
  `nombreEstadio` varchar(50) NOT NULL,
  `ubicacion` varchar(100) NOT NULL,
  `capacidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estadios`
--

INSERT INTO `estadios` (`idEstadio`, `nombreEstadio`, `ubicacion`, `capacidad`) VALUES
(1, 'Estadio Azteca', 'Ciudad de México, México', 87000),
(2, 'Camp Nou', 'Barcelona, España', 99354),
(3, 'Santiago Bernabéu', 'Madrid, España', 81044),
(7, 'Ciudad de Vallecas', 'Madrid', 22000),
(8, 'Butarque', 'Madrid', 32000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jugadores`
--

CREATE TABLE `jugadores` (
  `idJugador` int(11) NOT NULL,
  `nombreJugador` varchar(40) NOT NULL,
  `apellidoJugador` varchar(40) NOT NULL,
  `posicion` varchar(20) NOT NULL,
  `edad` int(11) NOT NULL,
  `idEquipo` int(11) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `jugadores`
--

INSERT INTO `jugadores` (`idJugador`, `nombreJugador`, `apellidoJugador`, `posicion`, `edad`, `idEquipo`, `imagen`) VALUES
(2, 'Robert', 'Lewandowski', 'Delantero', 34, 2, 'lewandoski.jpg'),
(5, 'Vinicius', 'Junior', 'Extremo', 23, 3, 'vinicius.jpg'),
(17, 'Rodrygo', 'Goes', 'delantero', 23, 3, 'p440077_t186_2024_1_002_000.jpg'),
(18, 'Pau', 'Cubarsi', 'defensa', 18, 2, 'p593110_t178_2024_1_001_000.png'),
(19, 'isi', 'palazon', 'extremo', 32, 4, 'descarga (2).jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idUser` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `apellido` varchar(40) NOT NULL,
  `nombreUsuario` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `contrasenya` varchar(256) NOT NULL,
  `nivel_usuario` int(11) NOT NULL DEFAULT 1,
  `imagen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idUser`, `nombre`, `apellido`, `nombreUsuario`, `contrasenya`, `nivel_usuario`, `imagen`) VALUES
(1, 'Raúl', 'Fos', 'raulfos', 'hashed_password_123', 1, 'https://example.com/images/raul.jpg'),
(2, 'Maria', 'Perez', 'mariap', 'hashed_password_456', 2, 'https://example.com/images/maria.jpg'),
(3, 'Carlos', 'Gomez', 'carlosg', 'hashed_password_789', 1, 'https://example.com/images/carlos.jpg'),
(4, 'patatas', 'fos', 'raulo22', '$2y$10$aIiJAP2U7DtdQ67n95HGv.ygXmh9c3B5x9fI2gBRzGwZCXQXoYKy2', 1, 'raulo22.jpg'),
(5, 'Admin', 'User', 'admin', '$2a$07$usesomesillystringforsalt$1Tj/NlMZXHlRh3MXBkt6q/', 2, NULL),
(6, 'a', 'fos', 'aaa', '$2y$10$H8m7l.tIFTgDG5GB6sB4GOBBWpC1DGfG8NMDHsKlowfW2t0QmpPHq', 2, NULL),
(7, 'Rodrygo', 'fos', 'bbb', '$2y$10$3NgMHpvccpERQy5Qe4nOqOBmZANMkP5Ksi95JPCR6VyoNiQyaVl6m', 1, NULL),
(8, 'Rodrygo', 'fos', 'raulo222', '$2y$10$83uVi4jJk494X/QjNE5TduHlP/UZwSYZlJm8ceqpcp4iLUPet.1qa', 1, NULL),
(9, 'Rodrygo', 'fos', 'raulo222a', '$2y$10$rvHBzccnnw9snUz1kGXggeHVSmNtPe3BdnxDNoxuT6INXkGbJnYym', 1, NULL),
(11, 'Rodrygo', 'fos', 'raulo22bb', '$2y$10$hJmk0PZi.hZwd9pdprWsbeQ41TZPXouQWpp6Aan5D7ifNysKZS1zC', 1, NULL),
(12, 'xavi', 'fos', 'xavi777', '$2y$10$KQerhbz2bFNo.Plad6vUsuEGOvDpHWV4CUnwy7NhmQ9DaZl7M.4ZW', 1, ''),
(13, 'as', 'sasasas', 'dfggf', '$2y$10$6qb7G5cwvTWtCEXJOVvqOuF5TnnL9r7QNS0SPnz4Ijl0v4UrTTPjG', 1, ''),
(14, 'prova', 'prova', 'poroor', '$2y$10$mQ6DBFStEw/9dnkgaBA3x.uNGPE98iAwt/b1vZ4Dpx.ghzt0sZA5G', 1, 'p440077_t186_2024_1_002_000.jpg'),
(15, 'Rodrygo', 'goes', 'rodg22', '$2y$10$1dJNZa4XBh.TraIByRCRAunLbVRh0zgXnsCzRuv680eMgJuHhVgSS', 1, 'p246333_t186_2024_1_002_000.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `equipos`
--
ALTER TABLE `equipos`
  ADD PRIMARY KEY (`idEquipo`),
  ADD KEY `idEstadio` (`idEstadio`);

--
-- Indices de la tabla `estadios`
--
ALTER TABLE `estadios`
  ADD PRIMARY KEY (`idEstadio`);

--
-- Indices de la tabla `jugadores`
--
ALTER TABLE `jugadores`
  ADD PRIMARY KEY (`idJugador`),
  ADD KEY `idEquipo` (`idEquipo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUser`),
  ADD UNIQUE KEY `nombreUsuario` (`nombreUsuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `equipos`
--
ALTER TABLE `equipos`
  MODIFY `idEquipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `estadios`
--
ALTER TABLE `estadios`
  MODIFY `idEstadio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `jugadores`
--
ALTER TABLE `jugadores`
  MODIFY `idJugador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `equipos`
--
ALTER TABLE `equipos`
  ADD CONSTRAINT `equipos_ibfk_1` FOREIGN KEY (`idEstadio`) REFERENCES `estadios` (`idEstadio`) ON DELETE CASCADE;

--
-- Filtros para la tabla `jugadores`
--
ALTER TABLE `jugadores`
  ADD CONSTRAINT `jugadores_ibfk_1` FOREIGN KEY (`idEquipo`) REFERENCES `equipos` (`idEquipo`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
