<?php

class Estadio extends Modelo {
    
    
    public function listarEstadios() {
        $consulta = "SELECT * FROM balonpie.estadios ORDER BY capacidad ASC";
        $result = $this->conexion->query($consulta);
        return $result->fetchAll(PDO::FETCH_ASSOC);

    }
    public function verEstadio($idestadio) {
        $consulta = "SELECT * FROM balonpie.estadios WHERE idEstadio=:idestadio";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':idestadio', $idestadio);
        $result->execute();
        return $result->fetch(PDO::FETCH_ASSOC);
    }
    
    
    
   
    
    public function insertarEstadio($nom, $capacidad, $ubicacion) {
        $consulta = "INSERT INTO balonpie.estadios (nombreEstadio, ubicacion, capacidad) VALUES (:nom, :ubicacion, :capacidad)";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':ubicacion', $ubicacion);
        $result->bindParam(':nom', $nom);
        $result->bindParam(':capacidad', $capacidad);
        $result->execute();  
        return $result;
    }
    
}
?>