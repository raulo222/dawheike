<?php

class Jugador extends Modelo {
    
    public function consultarUsuario($nombreUsuario) {
        $consulta = "SELECT * FROM balonpie.usuarios WHERE nombreUsuario=:nombreUsuario ";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':nombreUsuario', $nombreUsuario);
        $result->execute();
        return $result->fetch(PDO::FETCH_ASSOC);
    }
    
    public function insertarUsuario($nombre, $apellido, $nombreUsuario, $contrasenya,$img) {
        $consulta = "INSERT INTO balonpie.usuarios (nombre, apellido, nombreUsuario, contrasenya, imagen) VALUES (:nombre, :apellido, :nombreUsuario, :contrasenya, :img)";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':nombre', $nombre);
        $result->bindParam(':apellido', $apellido);
        $result->bindParam(':nombreUsuario', $nombreUsuario);
        $result->bindParam(':contrasenya', $contrasenya);
        $result->bindParam(':img', $img);
        $result->execute();
        return $result;
    }
    
    public function listarJugadores() {
        $consulta = "SELECT * FROM balonpie.jugadores ORDER BY edad ASC";
        $result = $this->conexion->query($consulta);
        return $result->fetchAll(PDO::FETCH_ASSOC);

    }
    
    public function verJug($idJug) {
        $consulta = "SELECT * FROM balonpie.jugadores WHERE idJugador=:idJug";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':idJug', $idJug);
        $result->execute();
        return $result->fetch(PDO::FETCH_ASSOC);
    }
    
    public function buscarJugNom($nom) {
        $consulta = "SELECT * FROM balonpie.jugadores WHERE nombreJugador=:nom";
        
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':nom', $nom);
        $result->execute();
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function buscarJugNomPos($posicion) {
        $consulta = "SELECT * FROM balonpie.jugadores WHERE posicion=:posicion";
        
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':posicion', $posicion);
        $result->execute();
        
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function buscarJugEdad($edad) {
        $consulta = "SELECT * FROM balonpie.jugadores WHERE edad=:edad";
        
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':edad', $edad);
        $result->execute();    
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
    public function buscarJugEqui($idEquipo) {
        $consulta = "SELECT * FROM balonpie.jugadores WHERE idEquipo=:idEquipo";
        
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':idEquipo', $idEquipo);
        $result->execute();    
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    
      
    public function insertarJugador($nom, $apellido, $edad, $equip,$posicion,$image) {
        $consulta = "INSERT INTO balonpie.jugadores (nombreJugador, apellidoJugador, edad, idEquipo, posicion, imagen) VALUES (:nom, :apellido, :edad, :equip, :posicion, :imagen)";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':nom', $nom);
        $result->bindParam(':apellido', $apellido);
        $result->bindParam(':edad', $edad);
        $result->bindParam(':equip', $equip);
        $result->bindParam(':posicion', $posicion);
        $result->bindParam(':imagen', $image);
        $result->execute();        
        return $result;
    }
    
}
?>