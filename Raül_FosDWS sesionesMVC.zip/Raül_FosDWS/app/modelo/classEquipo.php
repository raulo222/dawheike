<?php

class Equipo extends Modelo {
    
    
    public function listarEquips() {
        $consulta = "SELECT * FROM balonpie.equipos ORDER BY idEquipo ASC";
        $result = $this->conexion->query($consulta);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function verEquid($idEquipos) {
        $consulta = "SELECT * FROM balonpie.equipos WHERE idEquipo=:idEquipos";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':idEquipos', $idEquipos);
        $result->execute();
        return $result->fetch(PDO::FETCH_ASSOC);
    }
    
    public function buscarEquNom($nom) {
        $consulta = "SELECT * FROM balonpie.jugadores WHERE nombreEquipo=:nom";
        
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':nom', $nom);
        $result->execute();
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function buscarEquEstadio($estadio) {
        $consulta = "SELECT * FROM balonpie.jugadores WHERE idEstadio=:estadio";
        
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':estadio', $estadio);
        $result->execute();
        
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }
    
   
    
    public function insertarEquipo($nom, $estadio ) {
        $consulta = "INSERT INTO balonpie.equipos (idEstadio, nombreEquipo) VALUES (:estadio, :nom)";
        $result = $this->conexion->prepare($consulta);
        $result->bindParam(':nom', $nom);
        $result->bindParam(':estadio', $estadio);
        $result->execute();  
        return $result;
    }
    
}
?>