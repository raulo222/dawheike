<?php

class Controller
{
 
    //Método que se encarga de cargar el menu que corresponda según el tipo de usuario
    private function cargaMenu()
    {
        if ($_SESSION['nivel_usuario'] == 0) {
            return 'menuInvitado.php';
        } else if ($_SESSION['nivel_usuario'] == 1) {
            return 'menuUser.php';
        } else if ($_SESSION['nivel_usuario'] == 2) {
            return 'menuAdmin.php';
        }
    }


    public function home()
    {

        $params = array(
            'mensaje' => 'Bienvenido a la futbolpedia',
            'mensaje2' => 'El sitio web de los mas futboleros',
            'fecha' => date('d-m-Y')
        );
        $menu = 'menuHome.php';

        if ($_SESSION['nivel_usuario'] > 0) {
            header("location:index.php?ctl=inicio");
        }
        require __DIR__ . '/../../web/templates/inicio.php';
    }
    public function inicio()
    {


        $params = array(
            'mensaje' => 'Bienvenido a la futbolpedia',
            'mensaje2' => 'El sitio web de los mas futboleros',
            'fecha' => date('d-m-Y')
        );
        $menu = $this->cargaMenu();

        require __DIR__ . '/../../web/templates/inicio.php';
    }


    public function salir()
    {
        session_destroy();

        header("location:index.php?ctl=home");
    }

    public function error()
    {

        $menu = $this->cargaMenu();

        require __DIR__ . '/../../web/templates/error.php';
    }

    public function iniciarSesion()
    {
        try {
            $params = array(
                'nombreUsuario' => '',
                'contrasenya' => ''
            );
            $menu = $this->cargaMenu();

            if ($_SESSION['nivel_usuario'] > 0) {
                header("location:index.php?ctl=inicio");
            }
            if (isset($_POST['bIniciarSesion'])) { // Nombre del boton del formulario
                $nombreUsuario = recoge('nombreUsuario');
                $contrasenya = recoge('contrasenya');

                // Comprobar campos formulario. Aqui va la validación con las funciones de bGeneral   
                if (cUser($nombreUsuario, "nombreUsuario", $params)) {
                    // Si no ha habido problema creo modelo y hago consulta                    
                    $m = new Jugador();
                    if ($usuario = $m->consultarUsuario($nombreUsuario)) {
                        // Compruebo si el password es correcto
                        if (comprobarhash($contrasenya, $usuario['contrasenya'])) {
                            // Obtenemos el resto de datos

                            $_SESSION['idUser'] = $usuario['idUser'];
                            $_SESSION['nombreUsuario'] = $usuario['nombreUsuario'];
                            $_SESSION['nivel_usuario'] = $usuario['nivel_usuario'];
                            $_SESSION['imagen'] = $usuario['imagen'];

                            header('Location: index.php?ctl=inicio');
                        }
                    } else {
                        $params = array(
                            'nombreUsuario' => $nombreUsuario,
                            'contrasenya' => $contrasenya
                        );
                        $params['mensaje'] = 'No se ha podido iniciar sesión. Revisa el formulario.';
                    }
                } else {
                    $params = array(
                        'nombreUsuario' => $nombreUsuario,
                        'contrasenya' => $contrasenya
                    );
                    $params['mensaje'] = 'Hay datos que no son correctos. Revisa el formulario.';
                }
            }
        } catch (Exception $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
            header('Location: index.php?ctl=error');
        } catch (Error $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
            header('Location: index.php?ctl=error');
        }
        require __DIR__ . '/../../web/templates/formInicioSesion.php';
    }


    public function registro()
    {
        $menu = $this->cargaMenu();
        if ($_SESSION['nivel_usuario'] > 0) {
            header("location:index.php?ctl=inicio");
        }


        $params = array(
            'nombre' => '',
            'apellido' => '',
            'nombreUsuario' => '',
            'contrasenya' => '',
            'file'=>''
        );
        $errores = array();
        if (isset($_POST['bRegistro'])) {
            $nombre = recoge('nombre');
            $apellido = recoge('apellido');
            $nombreUsuario = recoge('nombreUsuario');
            $contrasenya = recoge('contrasenya');
            

            // Comprobar campos formulario. Aqui va la validación con las funciones de bGeneral o la clase Validacion        
            // cFile($nombreUsuario,$errores,['jpg'],'usuariosimg/',20000,TRUE); 
            cTexto($nombre, "nombre", $errores);
            cTexto($apellido, "apellido", $errores);
            cUser($contrasenya, "contrasenya", $errores);
            cUser($nombreUsuario, "nombreUsuario", $errores);

            $extensionesValidas = ['jpg', 'jpeg', 'png'];
            $directorio = 'usuariosimg';
            $max_file_size = 2 * 1024 * 1024;

            $imagenGuardada = null;

            if (!empty($_FILES['file']['name'])) {  
                $imagenGuardada = cFile('file', $errores, $extensionesValidas, $directorio, $max_file_size);
                if (!$imagenGuardada) {
                    echo "Error al subir la imagen: " . implode(', ', $errores);
                }
            }
            if (empty($errores)) {
                // Si no ha habido problema creo modelo y hago inserción     
                try {
                    $m = new Jugador();
                    $imagenGuardada2=basename($imagenGuardada);
                    if ($m->insertarUsuario($nombre, $apellido, $nombreUsuario, encriptar($contrasenya), $imagenGuardada2)) {

                        header('Location: index.php?ctl=iniciarSesion');
                    } else {

                        $params = array(
                            'nombre' => $nombre,
                            'apellido' => $apellido,
                            'nombreUsuario' => $nombreUsuario,
                            'contrasenya' => $contrasenya
                        );

                        $params['mensaje'] = 'No se ha podido insertar el usuario. Revisa el formulario.';
                    }
                } catch (Exception $e) {
                    error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
                    header('Location: index.php?ctl=error');
                } catch (Error $e) {
                    error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
                    header('Location: index.php?ctl=error');
                }
            } else {
                $params = array(
                    'nombre' => $nombre,
                    'apellido' => $apellido,
                    'nombreUsuario' => $nombreUsuario,
                    'contrasenya' => $contrasenya
                );
                $params['mensaje'] = 'Hay datos que no son correctos. Revisa el formulario.';
            }
        }


        require __DIR__ . '/../../web/templates/formRegistro.php';
    }


    public function listarJugadores()
{
    try {
        $m = new Jugador();
        $params = array(
            'jugadores' => $m->listarJugadores(),
            'mensaje' => null
        );

        if (empty($params['jugadores'])) {
            $params['mensaje'] = "No hay jugadores que mostrar.";
        }
    } catch (Exception $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
        header('Location: index.php?ctl=error');
    } catch (Error $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
        header('Location: index.php?ctl=error');
    }

    $menu = $this->cargaMenu();
    require __DIR__ . '/../../web/templates/mostrarJugadores.php';
}
public function listarEstadios()
{
    try {
        $m = new Estadio();
        $params = array(
            'estadios' => $m->listarEstadios()
        );

        if (empty($params['estadios'])) {
            $params['mensaje'] = "No hay estadios que mostrar.";
        }
    } catch (Exception $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
        header('Location: index.php?ctl=error');
    } catch (Error $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
        header('Location: index.php?ctl=error');
    }

    $menu = $this->cargaMenu();
    require __DIR__ . '/../../web/templates/mostrarEstadios.php';
}
public function listarEquipos()
{
    try {
        $m = new Equipo();
        $params = array(
            'equips' => $m->listarEquips()
        );

        if (empty($params['equips'])) {
            $params['mensaje'] = "No hay equipos que mostrar.";
        }
    } catch (Exception $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
        header('Location: index.php?ctl=error');
    } catch (Error $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
        header('Location: index.php?ctl=error');
    }

    $menu = $this->cargaMenu();
    require __DIR__ . '/../../web/templates/mostrarEquipos.php';
}




    public function verJugador()
    {
        try {
            if (!isset($_GET['idJugador'])) {
                $params['mensaje'] = 'No hay jugadores que mostrar.';
            }
            $idJug = recoge('idJugador');
            $m = new Jugador();
            $params['jugadores'] = $m->verJug($idJug);
            if (!$params['jugadores']) {
                $params['mensaje'] = 'No hay jugadores que mostrar.';
            }
        } catch (Exception $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
            header('Location: index.php?ctl=error');
        } catch (Error $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
            header('Location: index.php?ctl=error');
        }

        $menu = $this->cargaMenu();

        require __DIR__ . '/../../web/templates/verLibro.php';
    }
    public function verEquip()
    {
        try {
            if (!isset($_GET['idEquip'])) {
                $params['mensaje'] = 'No hay equips que mostrar.';
            }
            $idEquip = recoge('idEquip');
            $m = new Equipo();
            $params['equipo'] = $m->verEquid($idEquip);
            if (!$params['equipo']) {
                $params['mensaje'] = 'No hay equips que mostrar.';
            }
        } catch (Exception $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
            header('Location: index.php?ctl=error');
        } catch (Error $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
            header('Location: index.php?ctl=error');
        }

        $menu = $this->cargaMenu();

        require __DIR__ . '/../../web/templates/verEquip.php';
    }


    public function buscarJugNom()
    {
        try {
            $params = array(
                'nombre' => '',
                'resultado' => array(),
                'jugadores' => array()
            );
            $m = new Jugador();
            if (isset($_POST['buscarJugNom'])) {
                $nom = recoge("titulo");
                $params['titulo'] = $nom;
                $params['jugadores'] = $m->buscarJugNom($nom);
                if (!$params['jugadores']) {
                    $params['mensaje'] = 'No hay jugadores que mostrar.';
                }
            }
        } catch (Exception $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
            header('Location: index.php?ctl=error');
        } catch (Error $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
            header('Location: index.php?ctl=error');
        }

        $menu = $this->cargaMenu();

        require __DIR__ . '/../../web/templates/buscarPorNombre.php';
    }


    public function buscarJugNomPos()
    {
        try {
            $params = array(
                'nombre' => '',
                'resultado' => array(),
                'jugadores' => array()
            );
            $m = new Jugador();
            if (isset($_POST['buscarJugNomPos'])) {
                $pos = recoge("posiciones");
                $params['posicion'] = $pos;
                $params['jugadores'] = $m->buscarJugNomPos($pos);
                if (!$params['jugadores']) {
                    $params['mensaje'] = 'No hay jugadores que mostrar.';
                }
            }
        } catch (Exception $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
            header('Location: index.php?ctl=error');
        } catch (Error $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
            header('Location: index.php?ctl=error');
        }

        $menu = $this->cargaMenu();

        require __DIR__ . '/../../web/templates/buscarPorPosicion.php';
    }


    public function buscarJugEdad()
    {
        try {
            $params = array(
                'edad' => '',
                'resultado' => array(),
                'jugadores'=>array()
            );
            $m = new Jugador();
            if (isset($_POST['buscarJugEdad'])) {
                $edad = recoge("edad");
                $params['edad'] = $edad;
                $params['jugadores'] = $m->buscarJugEdad($edad);
                if (!$params['jugadores']) {
                    $params['mensaje'] = 'No hay jugadores que mostrar.';
                }
            }
        } catch (Exception $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logExceptio.txt");
            header('Location: index.php?ctl=error');
        } catch (Error $e) {
            error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
            header('Location: index.php?ctl=error');
        }

        $menu = $this->cargaMenu();

        require __DIR__ . '/../../web/templates/buscarPorEdad.php';
    }







    public function insertarL()
{
    try {
        $params = array(
            'nombre' => '',
            'apellido' => '',
            'edad' => '',
            'posiciones' => '',
            'equipo' => ''
        );

        $errores = array();

        if (isset($_POST['bInsertarL'])) {  
            // Recoge valores del formulario
            $nombre = recoge('nombre');
            $apellido = recoge('apellido');
            $edad = recoge('edad');
            $posiciones = recoge('posiciones');
            $equipo = recoge('equipo');

            // Validaciones
            cTexto($nombre, "nombre", $errores);
            cTexto($apellido, "apellido", $errores);
            cNum($edad, "edad", $errores);
            cTexto($posiciones, "posiciones", $errores);

            // Configuración del archivo
            $extensionesValidas = ['jpg', 'jpeg', 'png'];
            $directorio = 'jugadores';
            $max_file_size = 2 * 1024 * 1024;

            $imagenGuardada = null;  // Variable para almacenar la ruta de la imagen

            if (!empty($_FILES['file']['name'])) {  
                $imagenGuardada = cFile('file', $errores, $extensionesValidas, $directorio, $max_file_size);
                if (!$imagenGuardada) {
                    echo "Error al subir la imagen: " . implode(', ', $errores);
                }
            }

            // Si no hay errores, insertar en la base de datos
            if (empty($errores)) {
                $m = new Jugador();
                $imagenGuardada2=basename($imagenGuardada);
                if ($m->insertarJugador($nombre, $apellido, $edad, $equipo, $posiciones,$imagenGuardada2)) {
                    header('Location: index.php?ctl=listarJugadores');
                    exit();
                } else {
                    $params['mensaje'] = 'No se ha podido insertar el jugador. Revisa el formulario.';
                }
            } else {
                $params['mensaje'] = 'Hay datos incorrectos. Revisa el formulario.';
            }
        }

    } catch (Exception $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logException.txt");
        header('Location: index.php?ctl=error');
    } catch (Error $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
        header('Location: index.php?ctl=error');
    }

    $menu = $this->cargaMenu();
    require __DIR__ . '/../../web/templates/formInsertarL.php';
}
public function insertarE()
{
    try {
        $params = array(
            'nombre' => '',
            'ubicacion' => '',
            'capacidad' => ''
        );
        

        $errores = array();

        if (isset($_POST['bInsertarE'])) {  
            // Recoge valores del formulario
            
            $nombre = recoge('nombre');
            $ubicacion = recoge('ubicacion');
            $capacidad = recoge('capacidad');
           
   
            // Validaciones
            cTexto($nombre, "nombre", $errores);
        
            cTexto($ubicacion, "ubicacion", $errores);
            
            cNum($capacidad, "capacidad", $errores);
            

            // Si no hay errores, insertar en la base de datos
            if (empty($errores)) {
                $m = new Estadio();
              
                if ($m->insertarEstadio($nombre, $capacidad,  $ubicacion)) {
                    
                    header('Location: index.php?ctl=listarEstadios');
                    exit();
                } else {
                    $params['mensaje'] = 'No se ha podido insertar el estadio. Revisa el formulario.';
                }
            } else {
                
                $params['mensaje'] = 'Hay datos incorrectos. Revisa el formulario.';
            }
        }

    } catch (Exception $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logException.txt");
        header('Location: index.php?ctl=error');
        exit();
    } catch (Error $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
        header('Location: index.php?ctl=error');
        exit();
    }

    $menu = $this->cargaMenu();
    require __DIR__ . '/../../web/templates/formInsertarE.php';
}
public function insertarEQ()
{
    try {
        $params = array(
            'nombre' => '',
            'estadio' => ''
        );
        

        $errores = array();

        if (isset($_POST['bInsertarEQ'])) {  
            // Recoge valores del formulario
            
            $nombre = recoge('nombre');
            $estadio = recoge('estadio');
           
           
   
            // Validaciones
            cTexto($nombre, "nombre", $errores);
        
            

            // Si no hay errores, insertar en la base de datos
            if (empty($errores)) {
                $m = new Equipo();
              
                if ($m->insertarEquipo($nombre,$estadio)) {
                    
                    header('Location: index.php?ctl=listarEquipos');
                    exit();
                } else {
                    $params['mensaje'] = 'No se ha podido insertar el estadio. Revisa el formulario.';
                }
            } else {
                
                $params['mensaje'] = 'Hay datos incorrectos. Revisa el formulario.';
            }
        }

    } catch (Exception $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logException.txt");
        header('Location: index.php?ctl=error');
        exit();
    } catch (Error $e) {
        error_log($e->getMessage() . microtime() . PHP_EOL, 3, "../app/log/logError.txt");
        header('Location: index.php?ctl=error');
        exit();
    }

    $menu = $this->cargaMenu();
    require __DIR__ . '/../../web/templates/formInsertarEQ.php';
}
}
