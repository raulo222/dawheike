<?php ob_start();
if (isset($params['mensaje'])) { 
    echo $params['mensaje'];
} ?>
<table>
    <tr>
        <th><h4><b>Nombre</b></h4><br></th>    
        <th><h4><b>Ubicación</b></h4><br></th>    
        <th><h4><b>Capacidad</b></h4><br></th>        
    </tr>
    
    <?php 
    $equipoModel = new Equipo(); // Crear una instancia del modelo Equipo
    foreach ($params['estadios'] as $estadio): 
        // Obtener el equipo correspondiente
    ?>
    <tr>
        <td class="tablaP">
        <?php echo htmlspecialchars($estadio['nombreEstadio'] ); ?>
        </td>
        <td class="mesllunt tablaP" > 
        <?php echo htmlspecialchars($estadio['ubicacion']); ?></td>
        <td class="mesllunt tablaP" >
        <?php echo htmlspecialchars($estadio['capacidad']); ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?php $contenido = ob_get_clean(); ?>

<?php include 'layout.php'; ?>
