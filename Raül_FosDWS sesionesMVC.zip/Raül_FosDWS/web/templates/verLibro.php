<?php
ob_start();
$equipoModel = new Equipo(); // Crear una instancia del modelo Equipo
$equipo = $equipoModel->verEquid($params['jugadores']['idEquipo']);
if (isset($params['mensaje'])) { 
	echo $params['mensaje'] ;
}else {
    ?>
	 
<b><span style="color: rgba(200, 119, 119, 1);"></span></b>

	<div class="container-fluid">
			<div class="container">
				<div class="row">				
					<div class="col-md-3">
						<p></p>
					</div>
					<div class="col-md-6">
						<h1 class="p-2"><?php echo $params['jugadores']['nombreJugador']." ".$params['jugadores']['apellidoJugador']?></h1>
						<img src="jugadores/<?php echo $params['jugadores']['imagen']; ?>" alt="Imagen del Jugador" class="jugadorimg">
						<table border="1" cellpadding="10">
							<tr align="center">
								<th>Nombre</th>
								<td><?php echo $params['jugadores']['nombreJugador']; ?></td>
							</tr>
							<tr align="center">
								<th>Edad</th>
								<td><?php echo $params['jugadores']['edad']; ?></td>
							</tr>
							<tr align="center">
								<th>Equipo</th>
								<td><?php echo $equipo['nombreEquipo'] ?></td>
							</tr>
							<tr align="center">
								<th>Posición</th>
								<td><?php echo $params['jugadores']['posicion']; ?></td>
							</tr>
						</table>
					</div>

					<div class="col-md-3">	            
              		
										
				</div>
			</div>
	</div>


<?php } $contenido = ob_get_clean();
include 'layout.php' ?>