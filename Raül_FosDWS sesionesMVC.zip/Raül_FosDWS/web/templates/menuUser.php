
<h3 class="text">Bienvenido <?php echo $_SESSION['nombreUsuario']?></h3>
<?php
if (isset($_SESSION['imagen']) && $_SESSION['imagen'] !== null) {
    // Si la sesión tiene una imagen, muestra la imagen personalizada
    echo '<img class="usuario" src="usuariosimg/' . $_SESSION['imagen'] . '">';
} else {
    // Si la sesión no tiene imagen (es null), muestra la imagen predeterminada
    echo '<img class="usuario" src="usuariosimg/null.jpg">';
}
?>

<div class="container-fluid menu text-center p-3 my-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12 ">
				<a href="index.php?ctl=home" class="p-4">INICIO</a>
				<a href="index.php?ctl=listarJugadores" class="p-4">JUGADORES</a>
				<a href="index.php?ctl=listarEquipos" class="p-4">EQUIPOS</a>
				<a href="index.php?ctl=listarEstadios" class="p-4">ESTADIOS</a>
				<a href="index.php?ctl=buscarJugNom" class="p-4">BUSCAR POR NOMBRE</a>
				<a href="index.php?ctl=buscarJugNomPos" class="p-4">BUSCAR POR POSICION</a>
				<a href="index.php?ctl=buscarJugEdad" class="p-4">BUSCAR POR EDAD</a>
				
				<a HREF="index.php?ctl=salir"><button TYPE="button" class="btn btn-secondary mt-3" style="width: 150px;">CERRAR SESIÓN</button></a>

			</div>
		</div>
	</div>
</div>