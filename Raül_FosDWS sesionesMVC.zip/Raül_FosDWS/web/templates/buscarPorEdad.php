<?php ob_start() ?>

<div class="container">
	<form name="buscarJugEdad" action="index.php?ctl=buscarJugEdad" method="POST">
		<table>
			<tr>
				<td>Edad del jugador </td>
				<td><input TYPE="text" NAME="edad" VALUE="<?php echo $params['edad'] ?>"></td>
				<td><input TYPE="submit" NAME="buscarJugEdad" VALUE="Buscar"></td>
			</tr>
		</table>
	</form>
</div>
<?php if (isset($params['mensaje'])) {
	echo $params['mensaje'];
}
if (count($params['jugadores']) > 0) { ?>

	<div class="container">
		<div class="row">

			<div class="col-md-4">
				<p></p>
			</div>

			<div class="col-md-4">
				<table border="1" cellpadding="10">
					<tr align="center">
						<th>Nombre</th>
						<th>Edad</th>
						<th>Posicion</th>
					</tr>
					<?php foreach ($params['jugadores'] as $jugadores) : ?>
						<tr align="center">
							<td><a href="index.php?ctl=verJugador&idJugador=<?php echo $jugadores['idJugador'] ?>"> <?php echo $jugadores['nombreJugador']; ?></a></td>
							<td><?php echo $jugadores['edad'] ?></td>
							<td><?php echo $jugadores['posicion'] ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>

			<div class="col-md-4">
				<p></p>
			</div>
		</div>
	</div>

<?php } ?>

<?php $contenido = ob_get_clean() ?>

<?php include 'layout.php' ?>