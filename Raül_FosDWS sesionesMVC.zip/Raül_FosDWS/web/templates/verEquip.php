<?php
ob_start();
$m = new Jugador();
$jugadors=$m->buscarJugEqui($params['equipo']['idEquipo']);
if (isset($params['mensaje'])) { 
	echo $params['mensaje'] ;
}else {
    ?>
	 
<b><span style="color: rgba(200, 119, 119, 1);"></span></b>

	<div class"container-fluid">
			<div class="container">
				<div class="row">				
					<div class="col-md-3">
						<p></p>
					</div>
					<div class="col-md-6">
						<h1 class="p-2"><?php echo $params['equipo']['nombreEquipo']?></h1>
						<table border="1" cellpadding="10">
							<tr align="center">
								<th>Nombre</th>
								<td><?php echo $params['equipo']['nombreEquipo']; ?></td>
							</tr>
							<tr align="center">
								<th>Estadio</th>
								<?php
								$estadio = new Estadio(); // Crear una instancia del modelo Equipo
								$equipo = $estadio->verEstadio($params['equipo']['idEstadio'])
								 ?>
								<td><?php echo $equipo['nombreEstadio'] ?></td>
							</tr>
							<tr>
								
							</tr>
							</tr>
							
						</table>
					</div>
					<h2>Jugadores Guardados</h2>
					<?php
			         foreach ($jugadors as $jugador): 
					?>
					<a href="index.php?ctl=verJugador&idJugador=<?php echo $jugador['idJugador']; ?>" class="tablaP">
					<?php echo htmlspecialchars($jugador['nombreJugador'] . " " . $jugador['apellidoJugador']); ?></a>
					<?php endforeach; ?>
					<div class="col-md-3">	            
              		
										
				</div>
			</div>
	</div>


<?php } $contenido = ob_get_clean();
include 'layout.php' ?>