<?php ob_start();
if (isset($params['mensaje'])) { 
    echo $params['mensaje'];
} ?>
<table>
    <tr>
        <th><h4><b>Jugadores</b></h4><br></th>    
        <th><h4><b>Edad</b></h4><br></th>    
        <th><h4><b>Equipo</b></h4><br></th>        
    </tr>
    
    <?php 
    $equipoModel = new Equipo(); // Crear una instancia del modelo Equipo
    foreach ($params['jugadores'] as $jugador): 
        $equipo = $equipoModel->verEquid($jugador['idEquipo']); // Obtener el equipo correspondiente
    ?>
    <tr>
        <td><a href="index.php?ctl=verJugador&idJugador=<?php echo $jugador['idJugador']; ?>" class="tablaP">
        <?php echo htmlspecialchars($jugador['nombreJugador'] . " " . $jugador['apellidoJugador']); ?></a></td>
        <td><a class="mesllunt"  class="tablaP">
        <?php echo htmlspecialchars($jugador['edad']); ?></a></td>
        <td class="mesllunt"><a href="index.php?ctl=verEquip&idEquip=<?php echo $jugador['idEquipo']; ?>" class="tablaP">
        <?php echo htmlspecialchars($equipo['nombreEquipo']); ?></a></td>
    </tr>
    <?php endforeach; ?>
</table>

<?php $contenido = ob_get_clean(); ?>

<?php include 'layout.php'; ?>
