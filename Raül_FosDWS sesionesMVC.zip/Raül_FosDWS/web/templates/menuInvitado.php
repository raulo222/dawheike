
<h3 class="text">Bienvenido Invitado</h3>
<div class="container-fluid menu text-center p-3 my-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12 ">
				<a href="index.php?ctl=home" class="p-5">INICIO</a>
				<a href="index.php?ctl=listarJugadores" class="p-5">JUGADORES</a>
				<a href="index.php?ctl=listarEstadios" class="p-5">ESTADIOS</a>
				<a href="index.php?ctl=listarEquipos" class="p-4">EQUIPOS</a>
				
			</div>
		</div>
	</div>
</div>