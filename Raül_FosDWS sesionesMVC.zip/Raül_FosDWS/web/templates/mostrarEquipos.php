<?php ob_start();
if (isset($params['mensaje'])) { 
    echo $params['mensaje'];
} 
 ?>
<table>
    <tr>
        <th><h4><b>Nombre</b></h4><br></th>    
              
    </tr>
    
    <?php 
    $equipoModel = new Equipo(); // Crear una instancia del modelo Equipo
    foreach ($params['equips'] as $equips): 
        // Obtener el equipo correspondiente
    ?>
    <tr>
    <td><a href="index.php?ctl=verEquip&idEquip=<?php echo $equips['idEquipo']; ?>" class="tablaP">
    <?php echo htmlspecialchars($equips['nombreEquipo'] ); ?>
    </a>
</td>
    </tr>
    <?php endforeach; ?>
</table>

<?php $contenido = ob_get_clean(); ?>

<?php include 'layout.php'; ?>
