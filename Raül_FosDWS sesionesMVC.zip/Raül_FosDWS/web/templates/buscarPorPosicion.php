<?php ob_start() ?>

<div class="container">
	<form name="formBusquedaAutor" action="index.php?ctl=buscarJugNomPos" method="POST">
		<table>
			<tr>
				<td>Posicion del jugador:</td>
				
				<td>
					<select id="posiciones" name="posiciones" VALUE="<?php echo $params['posiciones'] ?>">
				<option value="portero">Portero</option>
				<option value="defensa">Defensa</option>
				<option value="mediocampista">Mediocampista</option>
				<option value="extremo">Extremo</option>
				<option value="delantero">Delantero</option>
				
  				</select></td>
			
				<td><input TYPE="submit" NAME="buscarJugNomPos" VALUE="Buscar"></td>
			</tr>
		</table>
	</form>
</div>
<?php if (isset($params['mensaje'])) {
	echo $params['mensaje'];
}
if (count($params['jugadores']) > 0) : ?>

	<div class="container">
		<div class="row">

			<div class="col-md-4">
				<p></p>
			</div>

			<div class="col-md-4">
				<table border="1" cellpadding="10">
					<tr align="center">
						<th>Nombre</th>
						<th>Edad</th>
						<th>Posicion</th>
					</tr>
					<?php foreach ($params['jugadores'] as $jugadores) : ?>
						<tr align="center">
							<td><a href="index.php?ctl=verJugador&idJugador=<?php echo $jugadores['idJugador'] ?>"> <?php echo $jugadores['nombreJugador']; ?></a></td>
							<td><?php echo $jugadores['edad'] ?></td>
							<td><?php echo $jugadores['posicion'] ?></td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>

			<div class="col-md-4">
				<p></p>
			</div>
		</div>
	</div>

<?php endif; ?>

<?php $contenido = ob_get_clean() ?>

<?php include 'layout.php' ?>