<?php ob_start(); 
$a= new Equipo();
$equips = $a->listarEquips(); // Obtener el equipo correspondiente

?>

<div class="container text-center py-2">
	<div class="col-md-12">
			<?php if(isset($params['mensaje'])) :?>
				<b><span style="color: rgba(200, 119, 119, 1);"><?php echo $params['mensaje'] ?></span></b>
			<?php endif; ?>
	</div>
</div>

<div class="col-md-12">
			<?php foreach ($errores as $error) {?>
				<b><span style="color: rgba(200, 119, 119, 1);"><?php echo $error."<br>"; ?></span></b>
			<?php } ?>
</div>
<h1>Insertar jugador</h1>
<div class="container-fluid text-center" >
	<div class="container">
		<form ACTION="index.php?ctl=insertarL" METHOD="post" enctype="multipart/form-data">
			<p>Nombre<input TYPE="text" NAME="nombre" PLACEHOLDER="Nombre"><br></p>
			<p>Apellido <input TYPE="text" NAME="apellido" PLACEHOLDER="Apellido"><br></p>
			<p>Edad <input TYPE="number" NAME="edad" PLACEHOLDER="22"><br></p>
			<p>Posicion <select id="posiciones" name="posiciones" VALUE="<?php echo $params['posiciones'] ?>">
				<option value="portero">Portero</option>
				<option value="defensa">Defensa</option>
				<option value="mediocampista">Mediocampista</option>
				<option value="extremo">Extremo</option>
				<option value="delantero">Delantero</option>

				
  				</select>
				
			</p>
			<p>Club <select id="equipo" name="equipo" ?>">
				<?php
					foreach ($equips as $equip) {
						echo '<option value="'.$equip['idEquipo'].'">'.$equip['nombreEquipo'].'</option>';
					}
				?>
				
  				</select>
				
			</p>
			<p>Foto <input TYPE="file" NAME="file" ><br></p>
			
			
			<input TYPE="submit" name="bInsertarL" VALUE="Aceptar" PLACEHOLDER="Nombre de usuario"><br>
		</form>
	</div>
</div>

<?php $contenido = ob_get_clean() ?>

<?php include 'layout.php' ?>
