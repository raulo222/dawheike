<?php ob_start(); 
$a= new Equipo();
$equips = $a->listarEquips(); // Obtener el equipo correspondiente

?>

<div class="container text-center py-2">
	<div class="col-md-12">
			<?php if(isset($params['mensaje'])) :?>
				<b><span style="color: rgba(200, 119, 119, 1);"><?php echo $params['mensaje'] ?></span></b>
			<?php endif; ?>
	</div>
</div>

<div class="col-md-12">
			<?php foreach ($errores as $error) {?>
				<b><span style="color: rgba(200, 119, 119, 1);"><?php echo $error."<br>"; ?></span></b>
			<?php } ?>
</div>
<h1>Insertar Estadio</h1>
<div class="container-fluid text-center" >
	<div class="container">
		<form ACTION="index.php?ctl=insertarE" METHOD="post" enctype="multipart/form-data">
			<p>Nombre<input TYPE="text" NAME="nombre" PLACEHOLDER="Nombre"><br></p>
			<p>Ubicación<input TYPE="text" NAME="ubicacion" PLACEHOLDER="Madrid,Barcelona"><br></p>
			<p>Capaciad <input TYPE="number" NAME="capacidad" PLACEHOLDER="55.888"><br></p>
			<input TYPE="submit" name="bInsertarE" VALUE="Aceptar" PLACEHOLDER="Nombre de usuario"><br>
		</form>
	</div>
</div>

<?php $contenido = ob_get_clean() ?>

<?php include 'layout.php' ?>
