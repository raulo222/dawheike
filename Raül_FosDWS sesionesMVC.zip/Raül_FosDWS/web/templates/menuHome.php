

<div class="container-fluid menu text-center p-3 my-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12 ">
				<a href="index.php?ctl=iniciarSesion" class="p-5">INICIAR SESION</a>
				<a href="index.php?ctl=registro" class="p-5">REGISTRO</a>
				<a href="index.php?ctl=inicio" class="p-5">ENTRAR COMO INVITADO</a>
			</div>
		</div>
	</div>
</div>